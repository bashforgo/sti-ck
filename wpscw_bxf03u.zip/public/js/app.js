//this fires up the angular modules
angular.module('stick', ['ngRoute', 'appRoutes', 'MainCtrl', 'CreateCtrl', 'OrdersCtrl', 'SigninService', 'errSrcDirective', 'colorpicker.module']);