//just the db url
module.exports = {
	url : 'mongodb://wpscw:wpscw@oceanic.mongohq.com:10094/app23146302'
}